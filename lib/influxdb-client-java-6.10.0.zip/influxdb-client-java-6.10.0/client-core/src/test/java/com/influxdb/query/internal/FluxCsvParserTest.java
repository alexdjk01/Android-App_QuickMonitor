/*
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package com.influxdb.query.internal;

import java.io.IOException;
import java.lang.reflect.Field;
import java.nio.charset.Charset;
import java.time.Duration;
import java.time.Instant;
import java.util.Base64;
import java.util.List;
import java.util.function.Predicate;
import java.util.logging.Logger;
import javax.annotation.Nonnull;

import com.influxdb.Cancellable;
import com.influxdb.query.FluxColumn;
import com.influxdb.query.FluxRecord;
import com.influxdb.query.FluxTable;
import com.influxdb.query.exceptions.FluxCsvParserException;
import com.influxdb.query.exceptions.FluxQueryException;

import okio.Buffer;
import org.assertj.core.api.Assertions;
import org.assertj.core.util.Lists;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static java.nio.charset.StandardCharsets.UTF_8;

/**
 * @author Jakub Bednar (bednar@github) (16/07/2018 12:26)
 */
class FluxCsvParserTest {

    private static final Logger LOG = Logger.getLogger(FluxCsvParserTest.class.getName());

    private FluxCsvParser parser;

    @BeforeEach
    void setUp() {
        parser = new FluxCsvParser();
    }

    @Test
    void responseWithMultipleValues() throws IOException {

        // curl -i -XPOST --data-urlencode 'q=from(bucket: "ubuntu_test") |> last()
        // |> map(fn: (r) => ({value1: r._value, _value2:r._value * r._value, value_str: "test"}))'
        // --data-urlencode "orgName=0" http://localhost:8093/api/v2/query

        String data = "#datatype,string,long,dateTime:RFC3339,dateTime:RFC3339,string,string,string,string,long,long,string\n"
                + "#group,false,false,true,true,true,true,true,true,false,false,false\n"
                + "#default,_result,,,,,,,,,,\n"
                + ",result,table,_start,_stop,_field,_measurement,host,region,_value2,value1,value_str\n"
                + ",,0,1677-09-21T00:12:43.145224192Z,2018-07-16T11:21:02.547596934Z,free,mem,A,west,121,11,test\n"
                + ",,1,1677-09-21T00:12:43.145224192Z,2018-07-16T11:21:02.547596934Z,free,mem,B,west,484,22,test\n"
                + ",,2,1677-09-21T00:12:43.145224192Z,2018-07-16T11:21:02.547596934Z,usage_system,cpu,A,west,1444,38,test\n"
                + ",,3,1677-09-21T00:12:43.145224192Z,2018-07-16T11:21:02.547596934Z,user_usage,cpu,A,west,2401,49,test";

        List<FluxTable> tables = parseFluxResponse(data);

        List<FluxColumn> columnHeaders = tables.get(0).getColumns();
        Assertions.assertThat(columnHeaders).hasSize(11);
        FluxColumn fluxColumn1 = columnHeaders.get(0);
        LOG.info("FluxColumn1: " + fluxColumn1);

        Assertions.assertThat(fluxColumn1.isGroup()).isFalse();
        Assertions.assertThat(columnHeaders.get(1).isGroup()).isFalse();
        Assertions.assertThat(columnHeaders.get(2).isGroup()).isTrue();
        Assertions.assertThat(columnHeaders.get(3).isGroup()).isTrue();
        Assertions.assertThat(columnHeaders.get(4).isGroup()).isTrue();
        Assertions.assertThat(columnHeaders.get(5).isGroup()).isTrue();
        Assertions.assertThat(columnHeaders.get(6).isGroup()).isTrue();
        Assertions.assertThat(columnHeaders.get(7).isGroup()).isTrue();
        Assertions.assertThat(columnHeaders.get(8).isGroup()).isFalse();
        Assertions.assertThat(columnHeaders.get(9).isGroup()).isFalse();
        Assertions.assertThat(columnHeaders.get(10).isGroup()).isFalse();

        Assertions.assertThat(tables).hasSize(4);

        // Record 1
        FluxTable fluxTable1 = tables.get(0);
        LOG.info("FluxTable1: " + fluxTable1);

        Assertions.assertThat(fluxTable1.getRecords()).hasSize(1);

        FluxRecord fluxRecord1 = fluxTable1.getRecords().get(0);
        LOG.info("FluxRecord1: " + fluxRecord1);

        Assertions.assertThat(0).isEqualTo(fluxRecord1.getTable());
        Assertions.assertThat(fluxRecord1.getValues())
                .hasEntrySatisfying("host", value -> Assertions.assertThat(value).isEqualTo("A"))
                .hasEntrySatisfying("region", value -> Assertions.assertThat(value).isEqualTo("west"));
        Assertions.assertThat(fluxRecord1.getValues()).hasSize(11);
        Assertions.assertThat(fluxRecord1.getValue()).isNull();
        Assertions.assertThat(fluxRecord1.getValues())
                .hasEntrySatisfying("value1", value -> Assertions.assertThat(value).isEqualTo(11L))
                .hasEntrySatisfying("_value2", value -> Assertions.assertThat(value).isEqualTo(121L))
                .hasEntrySatisfying("value_str", value -> Assertions.assertThat(value).isEqualTo("test"));
        Assertions.assertThat(fluxRecord1.getValueByIndex(8)).isEqualTo(121L);
        Assertions.assertThat(fluxRecord1.getValueByIndex(9)).isEqualTo(11L);
        Assertions.assertThat(fluxRecord1.getValueByIndex(10)).isEqualTo("test");

        // Record 2
        FluxTable fluxTable2 = tables.get(1);
        LOG.info("FluxTable2: " + fluxTable2);

        Assertions.assertThat(fluxTable2.getRecords()).hasSize(1);

        FluxRecord fluxRecord2 = fluxTable2.getRecords().get(0);
        Assertions.assertThat(1).isEqualTo(fluxRecord2.getTable());
        Assertions.assertThat(fluxRecord2.getValues())
                .hasEntrySatisfying("host", value -> Assertions.assertThat(value).isEqualTo("B"))
                .hasEntrySatisfying("region", value -> Assertions.assertThat(value).isEqualTo("west"));
        Assertions.assertThat(fluxRecord2.getValues()).hasSize(11);
        Assertions.assertThat(fluxRecord2.getValue()).isNull();
        Assertions.assertThat(fluxRecord2.getValues())
                .hasEntrySatisfying("value1", value -> Assertions.assertThat(value).isEqualTo(22L))
                .hasEntrySatisfying("_value2", value -> Assertions.assertThat(value).isEqualTo(484L))
                .hasEntrySatisfying("value_str", value -> Assertions.assertThat(value).isEqualTo("test"));

        // Record 3
        FluxTable fluxTable3 = tables.get(2);
        LOG.info("FluxTable3: " + fluxTable3);

        Assertions.assertThat(fluxTable3.getRecords()).hasSize(1);

        FluxRecord fluxRecord3 = fluxTable3.getRecords().get(0);
        Assertions.assertThat(2).isEqualTo(fluxRecord3.getTable());
        Assertions.assertThat(fluxRecord3.getValues())
                .hasEntrySatisfying("host", value -> Assertions.assertThat(value).isEqualTo("A"))
                .hasEntrySatisfying("region", value -> Assertions.assertThat(value).isEqualTo("west"));
        Assertions.assertThat(fluxRecord3.getValues()).hasSize(11);
        Assertions.assertThat(fluxRecord3.getValue()).isNull();
        Assertions.assertThat(fluxRecord3.getValues())
                .hasEntrySatisfying("value1", value -> Assertions.assertThat(value).isEqualTo(38L))
                .hasEntrySatisfying("_value2", value -> Assertions.assertThat(value).isEqualTo(1444L))
                .hasEntrySatisfying("value_str", value -> Assertions.assertThat(value).isEqualTo("test"));

        // Record 4
        FluxTable fluxTable4 = tables.get(3);
        LOG.info("FluxTable4: " + fluxTable4);

        Assertions.assertThat(fluxTable4.getRecords()).hasSize(1);

        FluxRecord fluxRecord4 = fluxTable4.getRecords().get(0);
        Assertions.assertThat(3).isEqualTo(fluxRecord4.getTable());
        Assertions.assertThat(fluxRecord4.getValues())
                .hasEntrySatisfying("host", value -> Assertions.assertThat(value).isEqualTo("A"))
                .hasEntrySatisfying("region", value -> Assertions.assertThat(value).isEqualTo("west"));
        Assertions.assertThat(fluxRecord4.getValues()).hasSize(11);
        Assertions.assertThat(fluxRecord4.getValue()).isNull();
        Assertions.assertThat(fluxRecord4.getValues())
                .hasEntrySatisfying("value1", value -> Assertions.assertThat(value).isEqualTo(49L))
                .hasEntrySatisfying("_value2", value -> Assertions.assertThat(value).isEqualTo(2401L))
                .hasEntrySatisfying("value_str", value -> Assertions.assertThat(value).isEqualTo("test"));
    }

    @Test
    void shortcut() throws IOException {

        String data = "#datatype,string,long,dateTime:RFC3339,dateTime:RFC3339,dateTime:RFC3339,long,string,string,string,boolean\n"
                + "#group,false,false,false,false,false,false,false,false,false,true\n"
                + "#default,_result,,,,,,,,,true\n"
                + ",result,table,_start,_stop,_time,_value,_field,_measurement,host,value\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,true\n";

        List<FluxTable> tables = parseFluxResponse(data);

        Assertions.assertThat(tables).hasSize(1);
        Assertions.assertThat(tables.get(0).getRecords()).hasSize(1);

        FluxRecord fluxRecord = tables.get(0).getRecords().get(0);

        Assertions.assertThat(fluxRecord.getStart()).isEqualTo(Instant.parse("1970-01-01T00:00:10Z"));
        Assertions.assertThat(fluxRecord.getStop()).isEqualTo(Instant.parse("1970-01-01T00:00:20Z"));
        Assertions.assertThat(fluxRecord.getTime()).isEqualTo(Instant.parse("1970-01-01T00:00:10Z"));
        Assertions.assertThat(fluxRecord.getValue()).isEqualTo(10L);
        Assertions.assertThat(fluxRecord.getField()).isEqualTo("free");
        Assertions.assertThat(fluxRecord.getMeasurement()).isEqualTo("mem");
    }

    @Test
    void mappingBoolean() throws IOException {

        String data = "#datatype,string,long,dateTime:RFC3339,dateTime:RFC3339,dateTime:RFC3339,long,string,string,string,boolean\n"
                + "#group,false,false,false,false,false,false,false,false,false,true\n"
                + "#default,_result,,,,,,,,,true\n"
                + ",result,table,_start,_stop,_time,_value,_field,_measurement,host,value\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,true\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,false\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,x\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,\n";

        List<FluxTable> tables = parseFluxResponse(data);
        Assertions.assertThat(tables.get(0).getRecords().get(0).getValueByKey("value")).isEqualTo(true);
        Assertions.assertThat(tables.get(0).getRecords().get(1).getValueByKey("value")).isEqualTo(false);
        Assertions.assertThat(tables.get(0).getRecords().get(2).getValueByKey("value")).isEqualTo(false);
        Assertions.assertThat(tables.get(0).getRecords().get(3).getValueByKey("value")).isEqualTo(true);
    }

    @Test
    void mappingUnsignedLong() throws IOException {

        String data = "#datatype,string,long,dateTime:RFC3339,dateTime:RFC3339,dateTime:RFC3339,long,string,string,string,unsignedLong\n"
                + "#group,false,false,false,false,false,false,false,false,false,true\n"
                + "#default,_result,,,,,,,,,\n"
                + ",result,table,_start,_stop,_time,_value,_field,_measurement,host,value\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,17916881237904312345\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,\n";

        long expected = Long.parseUnsignedLong("17916881237904312345");

        List<FluxTable> tables = parseFluxResponse(data);
        Assertions.assertThat(tables.get(0).getRecords().get(0).getValueByKey("value")).isEqualTo(expected);
        Assertions.assertThat(tables.get(0).getRecords().get(1).getValueByKey("value")).isNull();
    }

    @Test
    void mappingDouble() throws IOException {

        String data = "#datatype,string,long,dateTime:RFC3339,dateTime:RFC3339,dateTime:RFC3339,long,string,string,string,double\n"
                + "#group,false,false,false,false,false,false,false,false,false,true\n"
                + "#default,_result,,,,,,,,,\n"
                + ",result,table,_start,_stop,_time,_value,_field,_measurement,host,value\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,12.25\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,\n";

        List<FluxTable> tables = parseFluxResponse(data);
        Assertions.assertThat(tables.get(0).getRecords().get(0).getValueByKey("value")).isEqualTo(12.25D);
        Assertions.assertThat(tables.get(0).getRecords().get(1).getValueByKey("value")).isNull();
    }

    @Test
    void mappingBase64Binary() throws IOException {

        String binaryData = "test value";
        String encodedString = Base64.getEncoder().encodeToString(binaryData.getBytes(UTF_8));

        String data = "#datatype,string,long,dateTime:RFC3339,dateTime:RFC3339,dateTime:RFC3339,long,string,string,string,base64Binary\n"
                + "#group,false,false,false,false,false,false,false,false,false,true\n"
                + "#default,_result,,,,,,,,,\n"
                + ",result,table,_start,_stop,_time,_value,_field,_measurement,host,value\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A," + encodedString + "\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,\n";

        List<FluxTable> tables = parseFluxResponse(data);

        byte[] value = (byte[]) tables.get(0).getRecords().get(0).getValueByKey("value");
        Assertions.assertThat(value).isNotNull();
        Assertions.assertThat(value).isNotEmpty();
        Assertions.assertThat(new String(value, UTF_8)).isEqualTo(binaryData);

        Assertions.assertThat(tables.get(0).getRecords().get(1).getValueByKey("value")).isNull();
    }

    @Test
    void mappingRFC3339() throws IOException {

        String data = "#datatype,string,long,dateTime:RFC3339,dateTime:RFC3339,dateTime:RFC3339,long,string,string,string,dateTime:RFC3339\n"
                + "#group,false,false,false,false,false,false,false,false,false,true\n"
                + "#default,_result,,,,,,,,,\n"
                + ",result,table,_start,_stop,_time,_value,_field,_measurement,host,value\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,1970-01-01T00:00:10Z\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,\n";

        List<FluxTable> tables = parseFluxResponse(data);
        Assertions.assertThat(tables.get(0).getRecords().get(0).getValueByKey("value")).isEqualTo(Instant.ofEpochSecond(10));
        Assertions.assertThat(tables.get(0).getRecords().get(1).getValueByKey("value")).isNull();
    }

    @Test
    void mappingRFC3339Nano() throws IOException {

        String data = "#datatype,string,long,dateTime:RFC3339,dateTime:RFC3339,dateTime:RFC3339,long,string,string,string,dateTime:RFC3339Nano\n"
                + "#group,false,false,false,false,false,false,false,false,false,true\n"
                + "#default,_result,,,,,,,,,\n"
                + ",result,table,_start,_stop,_time,_value,_field,_measurement,host,value\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,1970-01-01T00:00:10.999999999Z\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,\n";

        List<FluxTable> tables = parseFluxResponse(data);

        Assertions.assertThat(tables.get(0).getRecords().get(0).getValueByKey("value"))
                .isEqualTo(Instant.ofEpochSecond(10).plusNanos(999999999));
        Assertions.assertThat(tables.get(0).getRecords().get(1).getValueByKey("value"))
                .isNull();
    }

    @Test
    void mappingDuration() throws IOException {

        String data = "#datatype,string,long,dateTime:RFC3339,dateTime:RFC3339,dateTime:RFC3339,long,string,string,string,duration\n"
                + "#group,false,false,false,false,false,false,false,false,false,true\n"
                + "#default,_result,,,,,,,,,\n"
                + ",result,table,_start,_stop,_time,_value,_field,_measurement,host,value\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,125\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,\n";

        List<FluxTable> tables = parseFluxResponse(data);

        Assertions.assertThat(tables.get(0).getRecords().get(0).getValueByKey("value"))
                .isEqualTo(Duration.ofNanos(125));
        Assertions.assertThat(tables.get(0).getRecords().get(1).getValueByKey("value"))
                .isNull();
    }

    @Test
    void groupKey() throws IOException {

        String data = "#datatype,string,long,dateTime:RFC3339,dateTime:RFC3339,dateTime:RFC3339,long,string,string,string,duration\n"
                + "#group,false,false,false,false,true,false,false,false,false,true\n"
                + "#default,_result,,,,,,,,,\n"
                + ",result,table,_start,_stop,_time,_value,_field,_measurement,host,value\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,125\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,\n";

        List<FluxTable> tables = parseFluxResponse(data);

        Assertions.assertThat(tables.get(0).getColumns()).hasSize(10);
        Assertions.assertThat(tables.get(0).getGroupKey()).hasSize(2);
    }

    @Test
    void unknownTypeAsString() throws IOException {

        String data = "#datatype,string,long,dateTime:RFC3339,dateTime:RFC3339,dateTime:RFC3339,long,string,string,string,unknown\n"
                + "#group,false,false,false,false,false,false,false,false,false,true\n"
                + "#default,_result,,,,,,,,,\n"
                + ",result,table,_start,_stop,_time,_value,_field,_measurement,host,value\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,12.25\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,\n";

        List<FluxTable> tables = parseFluxResponse(data);
        Assertions.assertThat(tables.get(0).getRecords().get(0).getValueByKey("value")).isEqualTo("12.25");
        Assertions.assertThat(tables.get(0).getRecords().get(1).getValueByKey("value")).isNull();
    }

    @Test
    void error() {

        String data =
                "#datatype,string,string\n"
                        + "#group,true,true\n"
                        + "#default,,\n"
                        + ",error,reference\n"
                        + ",failed to create physical plan: invalid time bounds from procedure from: bounds contain zero time,897";

        Assertions.assertThatThrownBy(() -> parseFluxResponse(data))
                .isInstanceOf(FluxQueryException.class)
                .hasMessage("failed to create physical plan: invalid time bounds from procedure from: bounds contain zero time")
                .matches((Predicate<Throwable>) throwable -> ((FluxQueryException) throwable).reference() == 897);
    }

    @Test
    void errorWithoutReference() {

        String data =
                "#datatype,string,string\n"
                        + "#group,true,true\n"
                        + "#default,,\n"
                        + ",error,reference\n"
                        + ",failed to create physical plan: invalid time bounds from procedure from: bounds contain zero time,";

        Assertions.assertThatThrownBy(() -> parseFluxResponse(data))
                .isInstanceOf(FluxQueryException.class)
                .hasMessage("failed to create physical plan: invalid time bounds from procedure from: bounds contain zero time")
                .matches((Predicate<Throwable>) throwable -> ((FluxQueryException) throwable).reference() == 0);
    }

    @Test
    void parsingToConsumer() throws IOException {

        String data = "#datatype,string,long,dateTime:RFC3339,dateTime:RFC3339,dateTime:RFC3339,long,string,string,string,unknown\n"
                + "#group,false,false,false,false,false,false,false,false,false,true\n"
                + "#default,_result,,,,,,,,,\n"
                + ",result,table,_start,_stop,_time,_value,_field,_measurement,host,value\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,12.25\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,\n";

        List<FluxRecord> records = Lists.newArrayList();

        FluxCsvParser.FluxResponseConsumer consumer = new FluxCsvParser.FluxResponseConsumer() {
            @Override
            public void accept(final int index, @Nonnull final Cancellable cancellable, @Nonnull final FluxTable table) {

            }

            @Override
            public void accept(final int index, @Nonnull final Cancellable cancellable, @Nonnull final FluxRecord record) {
                records.add(record);
            }
        };

        Buffer buffer = new Buffer();
        buffer.writeUtf8(data);

        parser.parseFluxResponse(buffer, new DefaultCancellable(), consumer);
        Assertions.assertThat(records).hasSize(2);
    }

    @Test
    void cancelParsing() throws IOException {

        String data = "#datatype,string,long,dateTime:RFC3339,dateTime:RFC3339,dateTime:RFC3339,long,string,string,string,unknown\n"
                + "#group,false,false,false,false,false,false,false,false,false,true\n"
                + "#default,_result,,,,,,,,,\n"
                + ",result,table,_start,_stop,_time,_value,_field,_measurement,host,value\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,12.25\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,\n";

        List<FluxRecord> records = Lists.newArrayList();

        DefaultCancellable defaultCancellable = new DefaultCancellable();

        FluxCsvParser.FluxResponseConsumer consumer = new FluxCsvParser.FluxResponseConsumer() {
            @Override
            public void accept(final int index, @Nonnull final Cancellable cancellable, @Nonnull final FluxTable table) {

            }

            @Override
            public void accept(final int index, @Nonnull final Cancellable cancellable, @Nonnull final FluxRecord record) {
                defaultCancellable.cancel();
                records.add(record);
            }
        };

        Buffer buffer = new Buffer();
        buffer.writeUtf8(data);

        parser.parseFluxResponse(buffer, defaultCancellable, consumer);
        Assertions.assertThat(records).hasSize(1);
    }

    @Test
    void parsingWithoutTableDefinition() {

        String data = ",result,table,_start,_stop,_time,_value,_field,_measurement,host,value\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,12.25\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,\n";

        Assertions.assertThatThrownBy(() -> parseFluxResponse(data))
                .isInstanceOf(FluxCsvParserException.class)
                .hasMessage("Unable to parse CSV response. FluxTable definition was not found.");
    }

    @Test
    void enableParsingWithoutTableDefinition() throws IOException {

        String data = ",result,table,_start,_stop,_time,_value,_field,_measurement,host,value\n"
                + ",,0,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,12.25\n"
                + ",,1,1970-01-01T00:00:10Z,1970-01-01T00:00:20Z,1970-01-01T00:00:10Z,10,free,mem,A,15.55\n";

        parser = new FluxCsvParser(FluxCsvParser.ResponseMetadataMode.ONLY_NAMES);
        List<FluxTable> tables = parseFluxResponse(data);
        Assertions.assertThat(tables).hasSize(2);
        Assertions.assertThat(tables.get(0).getRecords()).hasSize(1);
        Assertions.assertThat(tables.get(0).getRecords().get(0).getValues().get("value")).isEqualTo("12.25");
        Assertions.assertThat(tables.get(0).getRecords().get(0).getValues().get("host")).isEqualTo("A");
        Assertions.assertThat(tables.get(1).getRecords()).hasSize(1);
        Assertions.assertThat(tables.get(1).getRecords().get(0).getValues().get("value")).isEqualTo("15.55");
        Assertions.assertThat(tables.get(1).getRecords().get(0).getValues().get("host")).isEqualTo("A");
    }

    @Test
    void multipleQueries() throws IOException {

        String data = "#datatype,string,long,string,string,dateTime:RFC3339,dateTime:RFC3339,dateTime:RFC3339,double,string\n"
                + "#group,false,false,true,true,true,true,false,false,true\n"
                + "#default,t1,,,,,,,,\n"
                + ",result,table,_field,_measurement,_start,_stop,_time,_value,tag\n"
                + ",,0,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:20:00Z,2,test1\n"
                + ",,0,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:21:40Z,2,test1\n"
                + ",,0,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:23:20Z,2,test1\n"
                + ",,0,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:25:00Z,2,test1\n"
                + ",,0,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:26:40Z,2,test1\n"
                + ",,0,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:28:20Z,2,test1\n"
                + ",,0,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:30:00Z,2,test1\n"
                + ",,1,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:20:00Z,2,test2\n"
                + ",,1,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:21:40Z,2,test2\n"
                + ",,1,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:23:20Z,2,test2\n"
                + ",,1,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:25:00Z,2,test2\n"
                + ",,1,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:26:40Z,2,test2\n"
                + ",,1,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:28:20Z,2,test2\n"
                + ",,1,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:30:00Z,2,test2\n"
                + "\n"
                + "#datatype,string,long,string,string,dateTime:RFC3339,dateTime:RFC3339,dateTime:RFC3339,double,string\n"
                + "#group,false,false,true,true,true,true,false,false,true\n"
                + "#default,t2,,,,,,,,\n"
                + ",result,table,_field,_measurement,_start,_stop,_time,_value,tag\n"
                + ",,0,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:20:00Z,2,test1\n"
                + ",,0,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:21:40Z,2,test1\n"
                + ",,0,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:23:20Z,2,test1\n"
                + ",,0,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:25:00Z,2,test1\n"
                + ",,0,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:26:40Z,2,test1\n"
                + ",,0,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:28:20Z,2,test1\n"
                + ",,0,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:30:00Z,2,test1\n"
                + ",,1,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:20:00Z,2,test2\n"
                + ",,1,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:21:40Z,2,test2\n"
                + ",,1,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:23:20Z,2,test2\n"
                + ",,1,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:25:00Z,2,test2\n"
                + ",,1,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:26:40Z,2,test2\n"
                + ",,1,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:28:20Z,2,test2\n"
                + ",,1,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:30:00Z,2,test2";

        List<FluxTable> tables = parseFluxResponse(data);
        Assertions.assertThat(tables).hasSize(4);
        Assertions.assertThat(tables.get(0).getRecords()).hasSize(7);
        Assertions.assertThat(tables.get(0).getRecords().get(0).getTable()).isEqualTo(0);
        Assertions.assertThat(tables.get(1).getRecords()).hasSize(7);
        Assertions.assertThat(tables.get(1).getRecords().get(0).getTable()).isEqualTo(1);
        Assertions.assertThat(tables.get(2).getRecords()).hasSize(7);
        Assertions.assertThat(tables.get(2).getRecords().get(0).getTable()).isEqualTo(2);
        Assertions.assertThat(tables.get(3).getRecords()).hasSize(7);
        Assertions.assertThat(tables.get(3).getRecords().get(0).getTable()).isEqualTo(3);
    }

    @Test
    void tableIndexNotStartAtZero() throws IOException {

        String data = "#datatype,string,long,string,string,dateTime:RFC3339,dateTime:RFC3339,dateTime:RFC3339,double,string\n"
                + "#group,false,false,true,true,true,true,false,false,true\n"
                + "#default,t1,,,,,,,,\n"
                + ",result,table,_field,_measurement,_start,_stop,_time,_value,tag\n"
                + ",,1,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:20:00Z,2,test1\n"
                + ",,1,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:21:40Z,2,test1\n"
                + ",,1,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:23:20Z,2,test1\n"
                + ",,1,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:25:00Z,2,test1\n"
                + ",,1,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:26:40Z,2,test1\n"
                + ",,1,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:28:20Z,2,test1\n"
                + ",,1,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:30:00Z,2,test1\n"
                + ",,2,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:20:00Z,2,test2\n"
                + ",,2,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:21:40Z,2,test2\n"
                + ",,2,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:23:20Z,2,test2\n"
                + ",,2,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:25:00Z,2,test2\n"
                + ",,2,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:26:40Z,2,test2\n"
                + ",,2,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:28:20Z,2,test2\n"
                + ",,2,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:30:00Z,2,test2\n";

        List<FluxTable> tables = parseFluxResponse(data);
        Assertions.assertThat(tables).hasSize(2);
        Assertions.assertThat(tables.get(0).getRecords()).hasSize(7);
        Assertions.assertThat(tables.get(0).getRecords().get(0).getTable()).isEqualTo(0);
        Assertions.assertThat(tables.get(1).getRecords()).hasSize(7);
        Assertions.assertThat(tables.get(1).getRecords().get(0).getTable()).isEqualTo(1);
    }

    @Test
    public void responseIsInUTF8() throws IOException, IllegalAccessException, NoSuchFieldException {

        String oldCharset = Charset.defaultCharset().toString();
        setDefaultCharset("GBK");
        try {
            String data = "#datatype,string,long,string,string,dateTime:RFC3339,dateTime:RFC3339,dateTime:RFC3339,double,string\n"
                    + "#group,false,false,true,true,true,true,false,false,true\n"
                    + "#default,t1,,,,,,,,\n"
                    + ",result,table,_field,_measurement,_start,_stop,_time,_value,tag\n"
                    + ",,1,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:20:00Z,2,ěščřĚŠČŘ Přerov 🍺\n";

            List<FluxTable> tables = parseFluxResponse(data);
            Assertions.assertThat(tables).hasSize(1);
            Assertions.assertThat(tables.get(0).getRecords()).hasSize(1);
            Assertions.assertThat(tables.get(0).getRecords().get(0).getValueByKey("tag")).isEqualTo("ěščřĚŠČŘ Přerov 🍺");
        } finally {
            setDefaultCharset(oldCharset);
        }
    }

    @Test
    public void responseWithError() {
        String data = "#datatype,string,long,string,string,dateTime:RFC3339,dateTime:RFC3339,dateTime:RFC3339,double,string\n"
                + "#group,false,false,true,true,true,true,false,false,true\n"
                + "#default,t1,,,,,,,,\n"
                + ",result,table,_field,_measurement,_start,_stop,_time,_value,tag\n"
                + ",,0,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:20:00Z,2,test1\n"
                + ",,0,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:21:40Z,2,test1\n"
                + ",,0,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:23:20Z,2,test1\n"
                + ",,0,value,python_client_test,2010-02-27T04:48:32.752600083Z,2020-02-27T16:48:32.752600083Z,2020-02-27T16:25:00Z,2,test1\n"
                + "\n"
                + "#datatype,string,string\n"
                + "#group,true,true\n"
                + "#default,,\n"
                + ",error,reference\n"
                + ",\"engine: unknown field type for value: xyz\",";

        Assertions.assertThatThrownBy(() -> parseFluxResponse(data))
                .isInstanceOf(FluxQueryException.class)
                .hasMessage("engine: unknown field type for value: xyz")
                .matches((Predicate<Throwable>) throwable -> ((FluxQueryException) throwable).reference() == 0);
    }

    @Test
    public void parseExportFromUserInterface() throws IOException {
            String data = "#group,false,false,true,true,true,true,true,true,false,false\n"
            + "#datatype,string,long,dateTime:RFC3339,dateTime:RFC3339,string,string,string,string,double,dateTime:RFC3339\n"
            + "#default,mean,,,,,,,,,\n"
            + ",result,table,_start,_stop,_field,_measurement,city,location,_value,_time\n"
            + ",,0,1754-06-26T11:30:27.613654848Z,2040-10-27T12:13:46.485Z,temperatureC,weather,London,us-midwest,30,1975-09-01T16:59:54.5Z\n"
            + ",,1,1754-06-26T11:30:27.613654848Z,2040-10-27T12:13:46.485Z,temperatureF,weather,London,us-midwest,86,1975-09-01T16:59:54.5Z\n";

        List<FluxTable> tables = parseFluxResponse(data);
        Assertions.assertThat(tables).hasSize(2);
        Assertions.assertThat(tables.get(0).getRecords()).hasSize(1);
        Assertions.assertThat(tables.get(0).getColumns().get(0).isGroup()).isFalse();
        Assertions.assertThat(tables.get(0).getColumns().get(1).isGroup()).isFalse();
        Assertions.assertThat(tables.get(0).getColumns().get(2).isGroup()).isTrue();
        Assertions.assertThat(tables.get(1).getRecords()).hasSize(1);
    }

    @Test
    public void parseInf() throws IOException {
         String data = "#group,false,false,true,true,true,true,true,true,true,true,false,false\n"
                 + "#datatype,string,long,dateTime:RFC3339,dateTime:RFC3339,string,string,string,string,string,string,double,double\n"
                 + "#default,_result,,,,,,,,,,,\n"
                 + ",result,table,_start,_stop,_field,_measurement,language,license,name,owner,le,_value\n"
                 + ",,0,2021-06-23T06:50:11.897825012Z,2021-06-25T06:50:11.897825012Z,stars,github_repository,C#,MIT License,influxdb-client-csharp,influxdata,0,0\n"
                 + ",,0,2021-06-23T06:50:11.897825012Z,2021-06-25T06:50:11.897825012Z,stars,github_repository,C#,MIT License,influxdb-client-csharp,influxdata,10,0\n"
                 + ",,0,2021-06-23T06:50:11.897825012Z,2021-06-25T06:50:11.897825012Z,stars,github_repository,C#,MIT License,influxdb-client-csharp,influxdata,20,0\n"
                 + ",,0,2021-06-23T06:50:11.897825012Z,2021-06-25T06:50:11.897825012Z,stars,github_repository,C#,MIT License,influxdb-client-csharp,influxdata,30,0\n"
                 + ",,0,2021-06-23T06:50:11.897825012Z,2021-06-25T06:50:11.897825012Z,stars,github_repository,C#,MIT License,influxdb-client-csharp,influxdata,40,0\n"
                 + ",,0,2021-06-23T06:50:11.897825012Z,2021-06-25T06:50:11.897825012Z,stars,github_repository,C#,MIT License,influxdb-client-csharp,influxdata,50,0\n"
                 + ",,0,2021-06-23T06:50:11.897825012Z,2021-06-25T06:50:11.897825012Z,stars,github_repository,C#,MIT License,influxdb-client-csharp,influxdata,60,0\n"
                 + ",,0,2021-06-23T06:50:11.897825012Z,2021-06-25T06:50:11.897825012Z,stars,github_repository,C#,MIT License,influxdb-client-csharp,influxdata,70,0\n"
                 + ",,0,2021-06-23T06:50:11.897825012Z,2021-06-25T06:50:11.897825012Z,stars,github_repository,C#,MIT License,influxdb-client-csharp,influxdata,80,0\n"
                 + ",,0,2021-06-23T06:50:11.897825012Z,2021-06-25T06:50:11.897825012Z,stars,github_repository,C#,MIT License,influxdb-client-csharp,influxdata,90,0\n"
                 + ",,0,2021-06-23T06:50:11.897825012Z,2021-06-25T06:50:11.897825012Z,stars,github_repository,C#,MIT License,influxdb-client-csharp,influxdata,+Inf,15\n"
                 + ",,0,2021-06-23T06:50:11.897825012Z,2021-06-25T06:50:11.897825012Z,stars,github_repository,C#,MIT License,influxdb-client-csharp,influxdata,-Inf,15\n"
                 + "\n";

        List<FluxTable> tables = parseFluxResponse(data);
        Assertions.assertThat(tables).hasSize(1);
        Assertions.assertThat(tables.get(0).getRecords()).hasSize(12);
        Assertions.assertThat(tables.get(0).getRecords().get(10).getValueByKey("le")).isEqualTo(Double.POSITIVE_INFINITY);
        Assertions.assertThat(tables.get(0).getRecords().get(11).getValueByKey("le")).isEqualTo(Double.NEGATIVE_INFINITY);
    }

    @Test
    public void parseDuplicateColumnNames() throws IOException {
        String data = "#datatype,string,long,dateTime:RFC3339,dateTime:RFC3339,dateTime:RFC3339,string,string,double\n" +
                "#group,false,false,true,true,false,true,true,false\n" +
                "#default,_result,,,,,,,\n" +
                " ,result,table,_start,_stop,_time,_measurement,location,result\n" +
                ",,0,2022-09-13T06:14:40.469404272Z,2022-09-13T06:24:40.469404272Z,2022-09-13T06:24:33.746Z,my_measurement,Prague,25.3\n" +
                ",,0,2022-09-13T06:14:40.469404272Z,2022-09-13T06:24:40.469404272Z,2022-09-13T06:24:39.299Z,my_measurement,Prague,25.3\n" +
                ",,0,2022-09-13T06:14:40.469404272Z,2022-09-13T06:24:40.469404272Z,2022-09-13T06:24:40.454Z,my_measurement,Prague,25.3\n";

        List<FluxTable> tables = parseFluxResponse(data);
        Assertions.assertThat(tables).hasSize(1);
        Assertions.assertThat(tables.get(0).getRecords()).hasSize(3);
        Assertions.assertThat(tables.get(0).getColumns()).hasSize(8);
        Assertions.assertThat(tables.get(0).getRecords().get(0).getValues().size()).isEqualTo(7);
        Assertions.assertThat(tables.get(0).getRecords().get(0).getRow().size()).isEqualTo(8);
        Assertions.assertThat(tables.get(0).getRecords().get(0).getRow().get(7)).isEqualTo(25.3);
    }

    @Nonnull
    private List<FluxTable> parseFluxResponse(@Nonnull final String data) throws IOException {


        Buffer buffer = new Buffer();
        buffer.writeUtf8(data);

        FluxCsvParser.FluxResponseConsumerTable consumer = parser.new FluxResponseConsumerTable();
        parser.parseFluxResponse(buffer, new DefaultCancellable(), consumer);

        return consumer.getTables();
    }

    private void setDefaultCharset(final String name) throws NoSuchFieldException, IllegalAccessException {
        String javaVersion = System.getProperty("java.version");
        // changing default charset using reflection does not work on newer jdk 16
        if (javaVersion.startsWith("1.8") || javaVersion.startsWith("11")) {
            Field charset = Charset.class.getDeclaredField("defaultCharset");
            charset.setAccessible(true);
            charset.set(null, Charset.forName(name));
        }
    }

    private static class DefaultCancellable implements Cancellable {


        private boolean cancelled = false;

        @Override
        public void cancel() {
            cancelled = true;
        }

        @Override
        public boolean isCancelled() {
            return cancelled;
        }
    }
}
